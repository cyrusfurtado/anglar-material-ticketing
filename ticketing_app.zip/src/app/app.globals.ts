
export const AppGlobals = {
    serverUrl: ''
}