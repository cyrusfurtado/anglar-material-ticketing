import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mainsidenav',
  templateUrl: './mainsidenav.component.html',
  styleUrls: ['./mainsidenav.component.css']
})
export class MainsidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
